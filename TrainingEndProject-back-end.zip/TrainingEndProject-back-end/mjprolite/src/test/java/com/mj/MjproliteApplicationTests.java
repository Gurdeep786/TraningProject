package com.mj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MjproliteApplicationTests {

	@Test
	void contextLoads() {
	}

}
