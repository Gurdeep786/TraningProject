package com.mj.utility;


public class AppConstant {
	
	public static final String CIPHER_KEY="KeyForEncryption";
	
}
